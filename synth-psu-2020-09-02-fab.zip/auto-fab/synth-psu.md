# PCB layout for USBC PSU

\ ![overview](auto-fab/synth-psu-overview.png)

# Configuration

* 95.1 x 35.1mm
* 1.6 mm FR4, white silkscreen, green/any mask
* 2 layers, 35um copper
* generated on 2020-09-02 14:11:31.029375, git version 5209428
